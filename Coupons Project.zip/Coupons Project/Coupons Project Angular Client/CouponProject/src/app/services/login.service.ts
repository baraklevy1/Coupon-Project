import { Injectable } from '@angular/core';
import { Login } from '../models/login';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class LoginService {

  public isLoggedIn: boolean;

  public loginType: string;

  public loggedStatus: number;

  public email: string;

  constructor(private httpClient: HttpClient) { 

    this.isLoggedIn = (localStorage.getItem("isLoggedIn") === "true");

    this.loginType = localStorage.getItem("loginType");

  }

  public checkLogin(login: Login) : void {

    this.httpClient.get<Response>("http://localhost:8080/" + login.loginType.toLowerCase() + "/login?name=" + login.name + "&password=" + login.password)
    .subscribe(res => this.loggedStatus = res.status);

  }

  public logout(): void {

    this.isLoggedIn = false;

    this.loginType = "";
    
    localStorage.removeItem("isLoggedIn");

    localStorage.removeItem("name");

    localStorage.removeItem("password");

    this.httpClient.post("http://localhost:8080/" + localStorage.getItem("loginType").toLowerCase + "/logout", null);

    localStorage.removeItem("loginType")
  }

  public createNewUser(login: Login) : void {
      this.httpClient.post<Response>("http://localhost:8080/admin/create" + login.loginType, login)
      .subscribe(res => this.loggedStatus = res.status); 
    }
}
