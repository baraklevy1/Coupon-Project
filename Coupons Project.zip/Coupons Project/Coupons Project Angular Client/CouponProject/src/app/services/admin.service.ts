import { Injectable } from '@angular/core';
import { Login } from '../models/login';
import { HttpClient } from '@angular/common/http';
import { Income } from '../models/Income';

@Injectable({
  providedIn: 'root'
})
export class AdminService {

  constructor(private HttpClient: HttpClient) { }

  public responseStatues: number;

  public allUsers: Login[];
  public error: string;

  public allIncome: Income[];

  public getAllCompanies(): void {
    this.HttpClient.get<Login[]>("http://localhost:8080/admin/getAllCompanies?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password"))
    .subscribe(res => this.allUsers = res, err => this.error = err);
  }

  public getAllCustomers(): void {
    this.HttpClient.get<Login[]>("http://localhost:8080/admin/getAllCustomers?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password"))
    .subscribe(res => this.allUsers = res, err => this.error = err);
  }

  public removeCompany(id: number): void {
    this.HttpClient.post<Response>("http://localhost:8080/admin/removeCompany?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password") + "&id=" + id, null)
    .subscribe(res => this.responseStatues = res.status, err => this.error = err);
  }

  public removeCustomer(id: number): void {
    this.HttpClient.post<Response>("http://localhost:8080/admin/removeCustomer?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password") + "&id=" + id, null)
    .subscribe(res => this.responseStatues = res.status, err => this.error = err);
  }

  
  public viewAllIncome(): void {
    this.HttpClient.get<Income[]>("http://localhost:8080/income//viewAllIncome?name="  + localStorage.getItem("name") + "&password=" + localStorage.getItem("password"))
    .subscribe(res => this.allIncome = res, err => this.error = err);
  }

  public viewIncomeByCompany(id: number): void {
    this.HttpClient.get<Income[]>("http://localhost:8080/admin/viewIncomeByCompany?id=" + id)
    .subscribe(res => this.allIncome = res, err => this.error = err);
  }

  public viewIncomeByCustomer(id: number): void {
    this.HttpClient.get<Income[]>("http://localhost:8080/admin/viewIncomeByCustomer?id=" + id)
    .subscribe(res => this.allIncome = res, err => this.error = err);
  }


  public viewAllIncome2(): void {
    this.HttpClient.get<Income[]>("http://localhost:8080/admin/viewAllIncome?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password"))
    .subscribe(res => this.allIncome = res, err => this.error = err);
  }

  public viewIncomeByCompany2(): void {
    this.HttpClient.get<Income[]>("http://localhost:8080/admin/viewCompanyIncome?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password") + "&id=" + 1)
    .subscribe(res => this.allIncome = res, err => this.error = err);
  }

  public viewIncomeByCustomer2(): void {
    this.HttpClient.get<Income[]>("http://localhost:8080/admin/viewCustomerIncome/viewIncome?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password"))
    .subscribe(res => this.allIncome = res, err => this.error = err);
  }

}
