import { Injectable } from '@angular/core';
import { Income } from '../models/Income';
import { HttpClient } from '@angular/common/http';

@Injectable({
  providedIn: 'root'
})
export class IncomeService {

  constructor(private HttpClient: HttpClient) { }

  public responseStatues: number;

  public allIncome: Income[];
  public error: string;

   // Both Company

   public customerViewIncome(): void {
    this.HttpClient.get<Income[]>("http://localhost:8080/income/customerViewIncome?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password"))
    .subscribe(res => this.allIncome = res, err => this.error = err);
  }

  public companyViewIncome(): void {
    this.HttpClient.get<Income[]>("http://localhost:8080/income/companyViewIncome?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password"))
    .subscribe(res => this.allIncome = res, err => this.error = err);
  }

}


