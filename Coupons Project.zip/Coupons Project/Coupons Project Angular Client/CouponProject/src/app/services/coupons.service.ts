import { Injectable } from '@angular/core';
import { Coupon } from '../models/coupon';
import { HttpClient } from '@angular/common/http';
// import { Company } from '../models/company';
import { Observable } from 'rxjs';

@Injectable({
  providedIn: 'root'
})
  export class CouponsService {

  public responseStatues: number;

  public allCouponsPath: string = "http://localhost:8080/admin/getAllCoupons";

  public allCouponsByTypePath: string = "http://localhost:8080/admin/getCouponsByType?type=";

  public couponPath: string = "http://localhost:8080/admin/getCoupon?id=";

  public allCoupons: Coupon[];
  public error: string;

  public category: String = "All";

  public coupon: Coupon;

  constructor(private HttpClient: HttpClient) { }

  public getAllCoupons(): void {
    this.HttpClient.get<Coupon[]>(this.allCouponsPath)
    .subscribe(res => this.allCoupons = res, err => this.error = err);
  }

  public getAllCouponsByType(): void {
    this.HttpClient.get<Coupon[]>(this.allCouponsByTypePath + this.category)
    .subscribe(res => this.allCoupons = res, err => this.error = err);
  }

  public getCoupon(id: number): void {
    this.HttpClient.get<Coupon>(this.couponPath + id)
    .subscribe(res => this.coupon = res, err => this.error = err);
  }


  // Company actions

  public createCoupon(coupon: Coupon): void {
    this.HttpClient.post<Response>("http://localhost:8080/company/createCoupon?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password"), coupon)
    .subscribe(res => this.responseStatues = res.status, err => this.error = err);
  }

  public removeCoupon(id: number): void {
    this.HttpClient.post<Response>("http://localhost:8080/company/removeCoupon?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password") + "&id=" + id, null)
    .subscribe(res => this.responseStatues = res.status, err => this.error = err);
  }

  public updateCoupon(coupon: Coupon): void {
    this.HttpClient.post<Response>("http://localhost:8080/company/updateCoupon?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password"), coupon)
    .subscribe(res => this.responseStatues = res.status, err => this.error = err);
  }

  public getCompanyCoupons(): void {
    this.HttpClient.get<Coupon[]>("http://localhost:8080/company/getAllCoupons?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password"))
    .subscribe(res => this.allCoupons = res, err => this.error = err);
  }

  public getCompanyCouponsByType(): void {
    this.HttpClient.get<Coupon[]>("http://localhost:8080/company/getAllCouponsByType?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password") + "&type=" + this.category)
    .subscribe(res => this.allCoupons = res, err => this.error = err);
  }

  public companyGetCoupon(id: number): void {
    this.HttpClient.get<Coupon>("http://localhost:8080/company/getCoupon?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password") + "&id=" + id)
    .subscribe(res => this.coupon = res, err => this.error = err);
  }

  
   // Company store income from creating coupon
  
   public storeIcomeCreateCoupon(): void {
    this.HttpClient.post<Response>("http://localhost:8080/income/companyCreateCouponIncome?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password"), null)
     .subscribe(res => this.responseStatues = res.status, err => this.error = err);
   }

   // Company store income from creating coupon
  
   public storeIcomeUpdateCoupon(): void {
    this.HttpClient.post<Response>("http://localhost:8080/income/companyUpdateCouponIncome?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password"), null)
     .subscribe(res => this.responseStatues = res.status, err => this.error = err);
   }


  // Customer actions

  public purchaseCoupon(id: number): void {
   this.HttpClient.get<Response>("http://localhost:8080/customer/purchaseCoupon?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password") + "&id=" + id)
    .subscribe(res => this.responseStatues = res.status, err => this.error = err);
  }

  public getCustomerCoupons(): void {
    this.HttpClient.get<Coupon[]>("http://localhost:8080/customer/getAllPurchasedCoupons?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password"))
    .subscribe(res => this.allCoupons = res, err => this.error = err);
  }

  public getCustomerCouponsByType(): void {
    this.HttpClient.get<Coupon[]>("http://localhost:8080/customer/getPurchasedCouponsByType?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password") + "&type=" + this.category)
    .subscribe(res => this.allCoupons = res, err => this.error = err);
  }

  public getCustomerCouponsUntilPrice(price: number): void {
    this.HttpClient.get<Coupon[]>("http://localhost:8080/customer/getPurchasedCouponsUntilPrice?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password") + "&price=" + price)
    .subscribe(res => this.allCoupons = res, err => this.error = err);
  }

   // Customer store income from coupon
  
   public storeIcomePurchaseCoupon(price: number): void {
    this.HttpClient.post<Response>("http://localhost:8080/income/customerStoreIncome?name=" + localStorage.getItem("name") + "&password=" + localStorage.getItem("password") + "&amount=" + price, null)
     .subscribe(res => this.responseStatues = res.status, err => this.error = err);
   }

}
