import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { HomeComponent } from './components/home/home.component';
import { CouponsComponent } from './components/coupons/coupons.component';
import { AboutComponent } from './components/about/about.component';
import { LoginComponent } from './components/login/login.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { CreateCouponComponent } from './components/create-coupon/create-coupon.component';
import { MyCouponsComponent } from './components/my-coupons/my-coupons.component';
import { ProfileComponent } from './components/profile/profile.component';
import { UpdateCouponComponent } from './components/update-coupon/update-coupon.component';
import { AdminComponent } from './components/admin/admin.component';


const routes: Routes = [
      { path: "home", component: HomeComponent},
      { path: "coupons", component: CouponsComponent},
      { path: "about", component: AboutComponent},
      { path: "login", component: LoginComponent},
      { path: "signUp", component: SignUpComponent},
      { path: "createCoupon", component: CreateCouponComponent},
      { path: "myCoupons", component: MyCouponsComponent},
      { path: "profile", component: ProfileComponent},
      { path: "updateCoupon", component: UpdateCouponComponent},
      { path: "admin", component: AdminComponent}
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
