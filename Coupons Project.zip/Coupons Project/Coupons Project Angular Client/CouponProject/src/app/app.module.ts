import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';

import { AppRoutingModule } from './app-routing.module';
import { LayoutComponent } from './components/layout/layout.component';
import { HeaderComponent } from './components/header/header.component';
import { MenuComponent } from './components/menu/menu.component';
import { HomeComponent } from './components/home/home.component';
import { FooterComponent } from './components/footer/footer.component';
import { AboutComponent } from './components/about/about.component';
import { CouponsComponent } from './components/coupons/coupons.component';

import { FormsModule } from "@angular/forms";
import { HttpClientModule } from "@angular/common/http";
import { ThumbnailComponent } from './components/thumbnail/thumbnail.component';
import { LoginComponent } from './components/login/login.component';
import { SignUpComponent } from './components/sign-up/sign-up.component';
import { CreateCouponComponent } from './components/create-coupon/create-coupon.component';
import { MyCouponsComponent } from './components/my-coupons/my-coupons.component';
import { ProfileComponent } from './components/profile/profile.component';
import { UpdateCouponComponent } from './components/update-coupon/update-coupon.component';
import { AdminComponent } from './components/admin/admin.component';

@NgModule({
  declarations: [LayoutComponent, HeaderComponent, MenuComponent, HomeComponent, FooterComponent, AboutComponent, CouponsComponent, ThumbnailComponent, LoginComponent, SignUpComponent, CreateCouponComponent, MyCouponsComponent, ProfileComponent, UpdateCouponComponent, AdminComponent],
  imports: [BrowserModule, AppRoutingModule, FormsModule, HttpClientModule],
  providers: [],
  bootstrap: [LayoutComponent]
})
export class AppModule { }
