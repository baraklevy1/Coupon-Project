export class Income {

    public constructor (
        public id?: number,
        public name?: string,
        public date?: string,
        public description?: string,
        public amount?: string
) {}

}