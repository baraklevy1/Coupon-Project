import { Identifiers } from '@angular/compiler/src/render3/r3_identifiers';
import { DatePipe } from '@angular/common';

export class Coupon {

    public categoryName: string;

    public constructor(
        public id?: number,
        public title?: string,
        public startDate?: string,
        public endDate?: string,
        public amount?: number,
        public category?: number, 
        public message?: string,
        public price?: number,
        public image?: string
    ) 
    {
        this.categoryName = this.getCategoryName();
    }

    public getCategoryName(): string {
        if (this.category == 0)
        return "Traveling".toUpperCase();
        if (this.category == 1)
        return "Food".toUpperCase();
        if (this.category == 2)
        return "Electricity".toUpperCase();
        if (this.category == 3)
        return "Health".toUpperCase();
        if (this.category == 4)
        return "Movies".toUpperCase();
        if (this.category == 5)
        return "Sport".toUpperCase();
        if (this.category == 6)
        return "Camping".toUpperCase();
        if (this.category == 7)
        return "Fashion".toUpperCase();
        if (this.category == 8)
        return "Studies".toUpperCase();
    }

}