import { Component, OnInit } from '@angular/core';
import { IncomeService } from 'src/app/services/income.service';
import { LoginService } from 'src/app/services/login.service';
import { Login } from 'src/app/models/login';

@Component({
  selector: 'app-profile',
  templateUrl: './profile.component.html',
  styleUrls: ['./profile.component.css']
})
export class ProfileComponent implements OnInit {

  public login: Login = new Login();

  constructor(public loginService: LoginService, public incomeService: IncomeService) { }

  ngOnInit() {
    this.login.name = localStorage.getItem("name");
    this.login.password = localStorage.getItem("password");
    this.login.loginType = localStorage.getItem("loginType");
    this.login.email = localStorage.getItem("email - " + this.login.name + " " + this.login.loginType);

    document.getElementById("name").innerHTML = "Name: " + this.login.name;

    document.getElementById("password").innerHTML = "Password: " + this.login.password;

    if (this.login.loginType == "Customer") { 
    this.incomeService.customerViewIncome();
    }
    if (this.login.loginType == "Company") { 
    this.incomeService.companyViewIncome();
    }
  }

  public updateEmail(): void {
    localStorage.setItem("email - " + this.login.name + " " + this.login.loginType, this.login.email);
    alert("Your email was updated successfully!");
  }

}
