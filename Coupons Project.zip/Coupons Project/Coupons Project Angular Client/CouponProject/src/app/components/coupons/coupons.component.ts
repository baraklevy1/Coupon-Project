import { Component, OnInit } from '@angular/core';
import { Coupon } from 'src/app/models/coupon';
import { CouponsService } from 'src/app/services/coupons.service';
import { LoginService } from 'src/app/services/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-coupons',
  templateUrl: './coupons.component.html',
  styleUrls: ['./coupons.component.css']
})
export class CouponsComponent implements OnInit {

  public constructor(public couponsService: CouponsService, private loginService: LoginService, private router: Router) { }

  public ngOnInit(): void {
    
    if(!this.loginService.isLoggedIn) {
      this.router.navigate(["/login"]);
    }

    this.couponsService.getAllCoupons();

  }

  public getCategory(): void {
    if (this.couponsService.category == "All") {
      this.couponsService.getAllCoupons();
    } else {
      this.couponsService.getAllCouponsByType();
    }
  }


  // Select a coupon and then you can buy it if you want.

  public getSelectCoupon(coupon: Coupon): void {

    if (!(localStorage.getItem("loginType") === "Company") && !(localStorage.getItem("loginType") === "Admin")) {

      if (confirm("Do you want to purchase coupon " + coupon.title + " for " + coupon.price + "$?")) {
        this.couponsService.purchaseCoupon(coupon.id);
        this.delayCheck(500, coupon.price);
      }
    }
  }

  async delayCheck(ms: number, price: number) {
    await new Promise(resolve => setTimeout(()=>resolve(), ms)).then(()=>this.checkPurchaseCoupon(price));
  }

  public checkPurchaseCoupon(price: number): void {
    if (this.couponsService.responseStatues == 200) {
      alert("Coupon was purchased successfully! :)");
      this.couponsService.storeIcomePurchaseCoupon(price);
    } 
    if (this.couponsService.responseStatues == 131) {
      alert("Coupon already purchased!");
    }
    if (this.couponsService.responseStatues == 141) {
      alert("No coupons left!");
    }
    if (this.couponsService.responseStatues == 500) {
      alert("Unable to purchase coupon!");
    }
  }


  public getCategoryName(category: number): string {
    if (category == 0)
    return "Traveling".toUpperCase();
    if (category == 1)
    return "Food".toUpperCase();
    if (category == 2)
    return "Electricity".toUpperCase();
    if (category == 3)
    return "Health".toUpperCase();
    if (category == 4)
    return "Movies".toUpperCase();
    if (category == 5)
    return "Sport".toUpperCase();
    if (category == 6)
    return "Camping".toUpperCase();
    if (category == 7)
    return "Fashion".toUpperCase();
    if (category == 8)
    return "Studies".toUpperCase();
  }

  

}

