import { Component, OnInit } from '@angular/core';
import { Login } from 'src/app/models/login';
import { LoginService } from 'src/app/services/login.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  public login: Login = new Login();

  constructor(private loginService: LoginService, private router: Router) { }

  ngOnInit() {
    this.login.loginType = "Customer";
    
    if (this.loginService.isLoggedIn) {
      this.router.navigate(["/home"]);
    }
  }

  public send(): void {
    this.loginService.checkLogin(this.login) 
    this.delayCheckLogin(500);
  }

  
  async delayCheckLogin(ms: number) {
    await new Promise(resolve => setTimeout(()=>resolve(), ms)).then(()=>this.check());
  }

  public check(): void {
    
    if (this.loginService.loggedStatus == 200) {

      this.loginService.isLoggedIn = true;

      localStorage.setItem("isLoggedIn", "true");

      this.loginService.loginType = this.login.loginType;

      localStorage.setItem("name", this.login.name);

      localStorage.setItem("password", this.login.password);

      localStorage.setItem("loginType", this.login.loginType);

      this.router.navigate(["/home"]);

    } else if (this.loginService.loggedStatus == 301) {
      alert("Invalid username or password!");
      document.getElementById("invalidLogin").innerHTML = "Invalid username or password!";

    }  else {
      alert("Unable to login!");
    }
  }
}


