import { Component, OnInit } from '@angular/core';
import { CouponsService } from 'src/app/services/coupons.service';
import { Coupon } from 'src/app/models/coupon';

@Component({
  selector: 'app-create-coupon',
  templateUrl: './create-coupon.component.html',
  styleUrls: ['./create-coupon.component.css']
})
export class CreateCouponComponent implements OnInit {

  constructor(private couponsService: CouponsService) { }

  public coupon: Coupon = new Coupon();

  ngOnInit() {
  }

  public createCoupon(coupon: Coupon): void {
    this.couponsService.createCoupon(coupon);
    this.delayCheckCreateCoupon(500);
  }


async delayCheckCreateCoupon(ms: number) {
  await new Promise(resolve => setTimeout(()=>resolve(), ms)).then(()=>this.check());
}

public check(): void {
  if (this.couponsService.responseStatues == 200) {
    alert("Coupon was created successfully!");
    this.couponsService.storeIcomeCreateCoupon();
  } else if (this.couponsService.responseStatues == 123) {
    alert("Coupon with this name already exists.")
  } else {
    alert("Unable to create coupon!")
  }

}

}
