import { Component, OnInit } from '@angular/core';
import { AdminService } from 'src/app/services/admin.service';
import { Login } from 'src/app/models/login';

@Component({
  selector: 'app-admin',
  templateUrl: './admin.component.html',
  styleUrls: ['./admin.component.css']
})
export class AdminComponent implements OnInit {

  public isCustomer: boolean;

  constructor(public adminService: AdminService) { }

  ngOnInit() {
    this.adminService.getAllCustomers();
    this.isCustomer = true;

    this.adminService.viewAllIncome();
  }

  public getSelectUser(user: Login) {
    
    if (this.isCustomer) {
      if (confirm("Do you want to delete the Customer " + user.name + " with id " + user.id + "???")) {
        if (confirm("Are you sure???!!!")) {
          this.adminService.removeCustomer(user.id);
          this.deleyCheckIfUserDeleted(500);
        }
      }
    }
    if (!(this.isCustomer)) {
      if (confirm("Do you want to delete the Company " + user.name + " with id " + user.id + "???")) {
        if (confirm("Are you sure???!!!")) {
          this.adminService.removeCompany(user.id);
          this.deleyCheckIfUserDeleted(500);
        }
      }
    }
  }

  async deleyCheckIfUserDeleted(ms: number) {
    await new Promise(resolve => setTimeout(()=>resolve(), ms)).then(()=>this.checkUserDeleted());
  }

  public checkUserDeleted(): void {
    if (this.adminService.responseStatues == 200) {
      alert("User was removed successfully!")
    } 
    if (this.adminService.responseStatues == 411 || this.adminService.responseStatues == 412) {
      alert("No such user!");
    }
    if (this.adminService.responseStatues == 500) {
      alert("Unable to removed user!");
    }
  }

  public getCustomers(): void {
    this.adminService.getAllCustomers();
    this.isCustomer = true;
  }

  public getCompanies(): void {
    this.adminService.getAllCompanies();
    this.isCustomer = false;
  }

  public getAllIncome(): void {
    this.adminService.viewAllIncome();
  }

  public getCustomerIncom(id: number): void {
    this.adminService.viewIncomeByCustomer(1);
  }

  public getCompanyIncome(id: number): void {
    this.adminService.viewIncomeByCompany(id);
  }

}
