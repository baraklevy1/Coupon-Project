import { Component, OnInit } from '@angular/core';
import { CouponsService } from 'src/app/services/coupons.service';
import { LoginService } from 'src/app/services/login.service';
import { Router } from '@angular/router';
import { Coupon } from 'src/app/models/coupon';

@Component({
  selector: 'app-my-coupons',
  templateUrl: './my-coupons.component.html',
  styleUrls: ['./my-coupons.component.css']
})
export class MyCouponsComponent implements OnInit {

  public price: number;

  public constructor(public couponsService: CouponsService, public loginService: LoginService, private router: Router) { }

  public ngOnInit(): void {
    
    if(!this.loginService.isLoggedIn) {
      this.router.navigate(["/login"]);
    }

    if (localStorage.getItem("loginType") === "Company") {
      this.couponsService.getCompanyCoupons();

    } else {

    this.couponsService.getCustomerCoupons();

    }

  }

  public getCategory(): void {
    if (this.couponsService.category == "All") {

      if (localStorage.getItem("loginType") === "Company") {
        this.couponsService.getCompanyCoupons();

      } else {

      this.couponsService.getCustomerCoupons();

      }
    }

    if (!(this.couponsService.category == "All")) {

      if (localStorage.getItem("loginType") === "Company") {
        this.couponsService.getCompanyCouponsByType();

      } else {

      this.couponsService.getCustomerCouponsByType();

      }
    }
  }

  public untilPrice(): void {
      this.couponsService.category == "All"
      this.couponsService.getCustomerCouponsUntilPrice(this.price);
  }

  public getSelectCoupon(coupon: Coupon): void {
    if (localStorage.getItem("loginType") === "Company") {
      if (confirm("Do you want to update coupon "  + coupon.title + "?")) {
        this.couponsService.getCoupon(coupon.id);
        this.router.navigate(["/updateCoupon"]);
      }
    }
  }

  public getCategoryName(category: number): string {
    if (category == 0)
    return "Traveling".toUpperCase();
    if (category == 1)
    return "Food".toUpperCase();
    if (category == 2)
    return "Electricity".toUpperCase();
    if (category == 3)
    return "Health".toUpperCase();
    if (category == 4)
    return "Movies".toUpperCase();
    if (category == 5)
    return "Sport".toUpperCase();
    if (category == 6)
    return "Camping".toUpperCase();
    if (category == 7)
    return "Fashion".toUpperCase();
    if (category == 8)
    return "Studies".toUpperCase();
  }

}