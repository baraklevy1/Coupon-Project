import { Component, OnInit } from '@angular/core';
import { CouponsService } from 'src/app/services/coupons.service';
import { Coupon } from 'src/app/models/coupon';

@Component({
  selector: 'app-update-coupon',
  templateUrl: './update-coupon.component.html',
  styleUrls: ['./update-coupon.component.css']
})
export class UpdateCouponComponent implements OnInit {

  constructor(private couponsService: CouponsService) { }

  public coupon: Coupon = new Coupon();

  public category: string;


  ngOnInit() {
    this.delayGetCoupon(100);
  }

  async delayGetCoupon(ms: number) {
    await new Promise(resolve => setTimeout(()=>resolve(), ms)).then(()=>this.getTheCoupon());
  }

  public getTheCoupon(): void {  
    this.coupon = this.couponsService.coupon;
    document.getElementById("name").innerHTML = "Name: " + this.coupon.title;
    this.category = this.getCategoryName(this.coupon.category);
  }

  // Update Coupon

  public updateCoupon(coupon: Coupon): void {
    coupon.category = this.getCategoryNumber(this.category);
    this.couponsService.updateCoupon(coupon);
      this.delayUpdateCoupon(500);
  }

  async delayUpdateCoupon(ms: number) {
    await new Promise(resolve => setTimeout(()=>resolve(), ms)).then(()=>this.checkUpdateCoupon());
  }

  public checkUpdateCoupon(): void {  
    if (this.couponsService.responseStatues == 200) {
      alert("Coupon was updated successfully!");
      this.couponsService.storeIcomeUpdateCoupon();
    } else {
      alert("Unable to update coupon!");
    }
  }
  
  // Delete Coupon

  public deleteCoupon(coupon: Coupon): void {
    if (confirm("Are you sure you want to delete this coupon?")) { 
      this.couponsService.removeCoupon(coupon.id);
      this.delayDeleteCoupon(500);
    }
  }

  async delayDeleteCoupon(ms: number) {
    await new Promise(resolve => setTimeout(()=>resolve(), ms)).then(()=>this.checkDeleteCoupon());
  }

  public checkDeleteCoupon(): void {  
    if (this.couponsService.responseStatues == 200) {
      alert("Coupon was deleted successfully!");
    } else {
      alert("Unable to delete coupon!");
    }
  }

  public getCategoryName(category: number): string {
    if (category == 0)
    return "Traveling";
    if (category == 1)
    return "Food";
    if (category == 2)
    return "Electricity";
    if (category == 3)
    return "Health";
    if (category == 4)
    return "Movies";
    if (category == 5)
    return "Sport";
    if (category == 6)
    return "Camping";
    if (category == 7)
    return "Fashion";
    if (category == 8)
    return "Studies";
  }

  public getCategoryNumber(c: string): number {
    if (c == "traveling") 
    return 0;
    if (c == "Food")
    return 1;
    if (c =="Electricity")
    return 2;
    if (c == "Health")
    return 3;
    if (c == "Movies")
    return 4;
    if (c == "Sport")
    return 5;
    if (c == "Camping") 
    return 6;
    if (c == "Fashion") 
    return 7;
    if (c == "Studies")
    return 8;
  }

}
