import { Component, OnInit } from '@angular/core';
import { LoginService } from 'src/app/services/login.service';
import { Router } from '@angular/router';
import { Login } from 'src/app/models/login';

@Component({
  selector: 'app-sign-up',
  templateUrl: './sign-up.component.html',
  styleUrls: ['./sign-up.component.css']
})
export class SignUpComponent implements OnInit {

  public login: Login = new Login();

  public isCompany: boolean;

  constructor(private loginService: LoginService, private router: Router) { }

  ngOnInit() {
    this.login.loginType = "Customer";

    if (this.loginService.isLoggedIn) {
      this.router.navigate(["/home"]);
    }
  }

  public Signup(): void {
    this.loginService.createNewUser(this.login);
    this.delayCheckSignup(500);
  }

  async delayCheckSignup(ms: number) {
    await new Promise(resolve => setTimeout(()=>resolve(), ms)).then(()=>this.check());
  }

  public check(): void {
    
    if (this.loginService.loggedStatus == 200) {

      alert("Sign Up successfully!");
      this.router.navigate(["/login"]);

    } else if (this.loginService.loggedStatus == 121 || this.loginService.loggedStatus == 122) {
      alert("This username already exists!");
      document.getElementById("nameExists").innerHTML = "This username already exists";

    } else {
    alert("Unable to signup!");
    }

  }

}
