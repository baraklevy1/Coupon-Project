import { Component, OnInit } from '@angular/core';
import { Title} from '@angular/platform-browser';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  public currPercent: number;
  public currDate: Date;
  public startingDate: Date;
  public endingDate: Date;
  public imageWidth: number;
  public isSummer: boolean;
  public isSummerSale: boolean;

  constructor(private title: Title) { }

  ngOnInit() {
    this.currPercent = 20;
    this.currDate = new Date;
    this.startingDate = new Date(2019, 7, 17);
    this.endingDate = new Date(2019, 8, 30);
    this.imageWidth = 300;

    const month = this.currDate.getMonth() + 1;
    this.isSummer = month >= 5 || month <= 9;
    this.isSummerSale = this.currDate >= this.startingDate || this.currDate <= this.endingDate;

    this.title.setTitle("Coupons Store | Home");
  }

  public decreaseImage(): void {
    this.imageWidth -= 10;
  }

  public increaseImage(): void {
    this.imageWidth += 10;
  }

  public resetImage(): void {
    this.imageWidth = 300;
  }

}
