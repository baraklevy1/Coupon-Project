package com.project.CouponsProject.repositories;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.project.CouponsProject.entities.Income;
import com.project.CouponsProject.entities.IncomeType;

@Repository
public interface IncomeRepository extends JpaRepository<Income, Long> {

}
