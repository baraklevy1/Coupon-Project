package com.project.CouponsProject.entities;

import java.time.LocalDate;
import java.time.format.DateTimeFormatter;

import com.fasterxml.jackson.annotation.JsonSetter;

import model.Coupon;

public class RemoteCoupon extends Coupon {

	@JsonSetter(value="startDate")
	public void setStartDate(String date) {
		DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate startDate = LocalDate.parse(date, dtFormatter);
		setStartDate(startDate);
	}
	
	@JsonSetter(value="endDate")
	public void setEndDate(String date) {
		DateTimeFormatter dtFormatter = DateTimeFormatter.ofPattern("yyyy-MM-dd");
		LocalDate endDate = LocalDate.parse(date, dtFormatter);
		setEndDate(endDate);	
	}
}
