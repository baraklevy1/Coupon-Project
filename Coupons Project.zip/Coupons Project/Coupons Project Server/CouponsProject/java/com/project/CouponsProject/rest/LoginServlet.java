package com.project.CouponsProject.rest;

import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import ex.InvalidLoginException;
import ex.SystemMalfunctionException;
import facade.AbsFacade;
import facade.CouponSystem;
import facade.LoginType;

@SuppressWarnings("serial")
public class LoginServlet extends HttpServlet {

	private static final String PARAM_LOGIN_TYPE = "loginType";
	private static final String PARAM_PASSWORD = "password";
	private static final String PARAM_USER_NAME = "userName";
	public static final String KEY_FACADE = "facade";

	@Override
	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		req.getRequestDispatcher("WEB-INF/login.html").forward(req, resp);
	}

	@Override
	protected void doPost(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
		// userName -> the inserted user name.
		// password -> the inserted password.
		// loginType -> The login type, one of: ADMIN, COMPANY, CUSTOMER
		String userName = req.getParameter(PARAM_USER_NAME);
		String password = req.getParameter(PARAM_PASSWORD);
		LoginType loginType = LoginType.valueOf(req.getParameter(PARAM_LOGIN_TYPE));

		HttpSession session = req.getSession(true);

		try {
			AbsFacade facade = CouponSystem.getInstance().login(userName, password, loginType);

			String pathURI;
			String facadeAttrName;
			switch (loginType) {
			case ADMIN:
				pathURI = "WEB-INF/admin.html";
				facadeAttrName = "facade_admin";
				break;
			case COMPANY:
				pathURI = "WEB-INF/company.html";
				facadeAttrName = "facade_company";
				break;
			default: /* CUSTOMER */
				pathURI = "WEB-INF/customer.html";
				facadeAttrName = "facade_customer";
				break;
			}

			req.getRequestDispatcher(pathURI).forward(req, resp);
			session.setAttribute(facadeAttrName, facade);

		} catch (InvalidLoginException | SystemMalfunctionException e) {
			resp.sendRedirect(req.getContextPath() + "/login");
		}

	}
}
