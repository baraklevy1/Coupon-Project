package com.project.CouponsProject.rest;

import java.time.LocalDate;
import java.util.Collection;
import java.util.Collections;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.CouponsProject.entities.Income;
import com.project.CouponsProject.entities.IncomeType;
import com.project.CouponsProject.resources.ServerError;

import ex.CouponAlreadyPurchasedException;
import ex.CouponNotExistsException;
import ex.InvalidLoginException;
import ex.NoSuchCustomerException;
import ex.SystemMalfunctionException;
import ex.ZeroCouponAmountException;
import facade.CompanyFacade;
import facade.CouponSystem;
import facade.CustomerFacade;
import facade.LoginType;
import model.Coupon;
import model.CouponCategory;
import model.Customer;

@RestController
@RequestMapping("customer")
public class CustomerService {
	
	@Context
	private HttpServletRequest request;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.GET, value = "/login", produces = MediaType.APPLICATION_JSON)
	private Response login(@RequestParam("name") String userName, @RequestParam("password") String password) {
			try {
				CustomerFacade facade = (CustomerFacade) CouponSystem.getInstance().login(userName, password,
						LoginType.CUSTOMER);
				return Response.ok("Login successfully!").build();
			} catch (InvalidLoginException e) {
				return Response.status(ServerError.INVALID_LOGIN).entity("Invalid Login Credentials!" + e.getMessage()).build();
			} catch (SystemMalfunctionException e) {
				return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unable to login!" + e.getMessage()).build();	
			}		
	}
	
	private CustomerFacade getFacade(String userName, String password) {
		try {
			return (CustomerFacade) CouponSystem.getInstance().login(userName, password,
					LoginType.CUSTOMER);
		} catch (InvalidLoginException e) {
			Response.status(ServerError.INVALID_LOGIN).entity("Invalid Login Credentials!" + e.getMessage()).build();
		}	catch (SystemMalfunctionException e) {
			Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unable to login!" + e.getMessage()).build();	
		}	
		return null;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.GET, value = "/purchaseCoupon", produces = MediaType.APPLICATION_JSON)
	public Response purchaseCoupon (@RequestParam("name") String userName, @RequestParam("password") String password, @RequestParam("id") long couponId) { //, @RequestParam("price") double price) {
		try {
			getFacade(userName, password).purchaseCoupon(couponId);
			return Response.ok("Coupon was purachased successfully!").build();
		} catch (ZeroCouponAmountException e) {
			return Response.status(ServerError.NO_COUPONS_LEFT).entity("No coupons left of this kind!" + e.getMessage()).build();
		} catch (CouponAlreadyPurchasedException e) {
			return Response.status(ServerError.COUPON_ALREADY_PURCHASED).entity("Coupon already purchased!" + e.getMessage()).build();
		}
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.GET, value = "/getAllPurchasedCoupons", produces = MediaType.APPLICATION_JSON)
	public Collection<Coupon> getAllPurchasedCoupons(@RequestParam("name") String userName, @RequestParam("password") String password) {	
		return getFacade(userName, password).getAllPurchasedCoupons();
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.GET, value = "/getPurchasedCouponsByType", produces = MediaType.APPLICATION_JSON)
	public Collection<Coupon> getPurchasedCouponsByType(@RequestParam("name") String userName, @RequestParam("password") String password, @RequestParam("type") String type) {	
		try {
			return getFacade(userName, password).getAllPurchasedCouponsByType(CouponCategory.valueOf(type.toUpperCase()));
		} catch (SystemMalfunctionException e) {
			Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unable to get all the coupons of type " + type.toString() + "!" + e.getMessage()).build();
			return Collections.emptyList();
		}	
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.GET, value = "/getPurchasedCouponsUntilPrice", produces = MediaType.APPLICATION_JSON)
	public Collection<Coupon> getPurchasedCouponsUntilPrice(@RequestParam("name") String userName, @RequestParam("password") String password, @RequestParam("price") double price) {			
		return getFacade(userName, password).getAllPurchasedCouponsByPrice(price);		
	}
	
	
}
