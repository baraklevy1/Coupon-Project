package com.project.CouponsProject;

import java.util.Collection;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.EnableAutoConfiguration;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.context.ConfigurableApplicationContext;
import org.springframework.context.annotation.Configuration;

import com.project.CouponsProject.entities.Income;
import com.project.CouponsProject.services.IncomeService;

import ex.InvalidLoginException;
import ex.SystemMalfunctionException;
import facade.AdminFacade;
import facade.CouponSystem;
import facade.LoginType;

@SpringBootApplication
public class CouponsProjectApplication {

	public static void main(String[] args) throws InvalidLoginException, SystemMalfunctionException {
		
		ConfigurableApplicationContext context = SpringApplication.run(CouponsProjectApplication.class, args);
		
		IncomeService incomeService = context.getBean(IncomeService.class);
		Collection<Income> allIncome = incomeService.viewAllIncome();
		System.out.println( allIncome );
		
	}

}
