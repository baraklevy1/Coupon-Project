package com.project.CouponsProject.services;

import java.util.Collection;

import com.project.CouponsProject.entities.Income;

import ex.NoSuchCustomerException;

public interface IncomeService {
	
	void storeIncome(Income income);
	
	Collection<Income> viewAllIncome();
	
	Collection<Income> viewIncomeByCustomer(String userName);
	
	Collection<Income> viewIncomeByCompany(String userName);

}
