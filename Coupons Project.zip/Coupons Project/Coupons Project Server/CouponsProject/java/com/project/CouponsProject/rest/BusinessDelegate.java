package com.project.CouponsProject.rest;

import java.time.LocalDate;
import java.time.ZoneId;
import java.util.Collection;
import java.util.Collections;

import javax.ws.rs.PathParam;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.CouponsProject.entities.Income;
import com.project.CouponsProject.entities.IncomeType;
import com.project.CouponsProject.services.IncomeService;

import ex.InvalidLoginException;
import ex.NoSuchCompanyException;
import ex.NoSuchCustomerException;
import ex.SystemMalfunctionException;
import facade.AdminFacade;
import facade.CouponSystem;
import facade.LoginType;

@RestController
@RequestMapping("income")
public class BusinessDelegate {
	
	
	@Autowired
	IncomeService incomeService;
	
	// Check validation before showing or creating the income.
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.POST, value = "/customerStoreIncome")
	public Response customerStoreIncome(@RequestParam("name") String userName, @RequestParam("password") String password, @RequestParam("amount") double amount) {
		try {
			CouponSystem.getInstance().login(userName, password,
					LoginType.CUSTOMER);
			
			Income income = new Income();
			
			income.setName(userName);
			income.setDescription(IncomeType.CUSTOMER_PURCHASE);
			income.setDate(LocalDate.now(ZoneId.of( "America/Montreal" )));
			income.setAmount(amount);
			
			incomeService.storeIncome(income);
			return Response.ok("Store icome successfully!").build();
		} catch (InvalidLoginException | SystemMalfunctionException e) {
			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unable to store the income!" + e.getMessage()).build();
		}
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.POST, value = "/companyCreateCouponIncome")
	public Response companyCreateCouponIncome(@RequestParam("name") String userName, @RequestParam("password") String password) {	
		try {
			CouponSystem.getInstance().login(userName, password,
					LoginType.COMPANY);
			
			Income income = new Income();
			
			income.setName(userName);
			income.setDescription(IncomeType.COMPANY_CREATE_COUPON);
			income.setDate(LocalDate.now());
			income.setAmount(100);
			
			incomeService.storeIncome(income);
			return Response.ok("Store icome successfully!").build();
		} catch (InvalidLoginException | SystemMalfunctionException e) {
			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unable to store the income!" + e.getMessage()).build();
		}
	}

	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.POST, value = "/companyUpdateCouponIncome")
	public Response companyUpdateCouponIncome(@RequestParam("name") String userName, @RequestParam("password") String password) {	
		try {
			CouponSystem.getInstance().login(userName, password,
					LoginType.COMPANY);
			
			Income income = new Income();
			
			income.setName(userName);
			income.setDescription(IncomeType.COMPANY_UPDATE_COUPON);
			income.setDate(LocalDate.now());
			income.setAmount(10);
			
			incomeService.storeIncome(income);
			return Response.ok("Store icome successfully!").build();
		} catch (InvalidLoginException | SystemMalfunctionException e) {
			e.printStackTrace();
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unable to store the income!" + e.getMessage()).build();
		}
	}
	
	// Admin view the company income.
	
	 @CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.GET, value = "/viewIncomeByCompany", produces = MediaType.APPLICATION_JSON)
	public Collection<Income> viewIncomeByCompany(@RequestParam("name") String userName, @RequestParam("password") String password, @PathParam("id") long companyId) {
		try {
			AdminFacade facade = (AdminFacade) CouponSystem.getInstance().login(userName, password,
					LoginType.ADMIN);
			String name = facade.getCompany(companyId).getName();
			return incomeService.viewIncomeByCompany(name);
		} catch (InvalidLoginException | SystemMalfunctionException | NoSuchCompanyException e) {
			e.printStackTrace();
			Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unable to get income!" + e.getMessage()).build();
		}
		return Collections.emptyList();
	}
	
	// Admin view the customer income.
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.GET, value = "/viewIncomeByCustomer", produces = MediaType.APPLICATION_JSON)
	public Collection<Income> viewIncomeByCustomer(@RequestParam("name") String userName, @RequestParam("password") String password, @PathParam("id") long customerId) {
		try {
			AdminFacade facade = (AdminFacade) CouponSystem.getInstance().login(userName, password,
					LoginType.ADMIN);
			String name = facade.getCustomer(customerId).getName();
			return incomeService.viewIncomeByCustomer(name);
		} catch (InvalidLoginException | SystemMalfunctionException | NoSuchCustomerException e) {
			e.printStackTrace();
			Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unable to get income!" + e.getMessage()).build();
		}
		return Collections.emptyList();		
	} 
	
	// Admin view all the income.
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.GET, value = "/viewAllIncome", produces = MediaType.APPLICATION_JSON)
	public Collection<Income> viewAllIncome(@RequestParam("name") String userName, @RequestParam("password") String password) {
		try {
			CouponSystem.getInstance().login(userName, password,
					LoginType.ADMIN);
			return incomeService.viewAllIncome();
		} catch (InvalidLoginException | SystemMalfunctionException e) {
			e.printStackTrace();
			Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unable to get income!" + e.getMessage()).build();
		}
		return Collections.emptyList();		
	}
	
	// Company view income.
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.GET, value = "/companyViewIncome", produces = MediaType.APPLICATION_JSON)
	public Collection<Income> companyViewIncome(@RequestParam("name") String userName, @RequestParam("password") String password) {
		try {
			CouponSystem.getInstance().login(userName, password,
					LoginType.COMPANY);
			return incomeService.viewIncomeByCompany(userName);
		} catch (InvalidLoginException | SystemMalfunctionException e) {
			e.printStackTrace();
			Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unable to get income!" + e.getMessage()).build();
		}
		return Collections.emptyList();
	}
	
	// Customer view income.
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.GET, value = "/customerViewIncome", produces = MediaType.APPLICATION_JSON)
	public Collection<Income> customerViewIncome(@RequestParam("name") String userName, @RequestParam("password") String password) {
		try {
			CouponSystem.getInstance().login(userName, password,
					LoginType.CUSTOMER);
			return incomeService.viewIncomeByCustomer(userName);
		} catch (InvalidLoginException | SystemMalfunctionException e) {
			e.printStackTrace();
			Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unable to get income!" + e.getMessage()).build();
		}
		return Collections.emptyList();
	}

}