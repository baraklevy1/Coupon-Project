package com.project.CouponsProject.entities;

public enum IncomeType {
	
	CUSTOMER_PURCHASE("Customer purcahsed coupon."), COMPANY_CREATE_COUPON("Company created a new coupon"), COMPANY_UPDATE_COUPON("Company update coupon");
	
	private String description;
	
	private IncomeType(String description) {
		this.description = description;
	}

	public String getDescription() {
		
		return description;
		
	}

}
