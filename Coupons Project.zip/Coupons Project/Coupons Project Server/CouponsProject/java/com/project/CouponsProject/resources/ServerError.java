package com.project.CouponsProject.resources;

public class ServerError {

	public static final int INVALID_LOGIN = 301;
	
	public static final int NO_SUCH_COMPANY = 411;
	public static final int NO_SUCH_CUSTOMER = 412;
	public static final int NO_SUCH_COUPON = 413;
	
	public static final int CUSTOMER_ALREADY_EXISTS = 121;
	public static final int COMPANY_ALREADY_EXISTS = 122;
	public static final int COUPON_ALREADY_EXISTS = 123;
	
	public static final int COUPON_ALREADY_PURCHASED = 131;
	
	public static final int NO_COUPONS_LEFT = 141;
	
}
