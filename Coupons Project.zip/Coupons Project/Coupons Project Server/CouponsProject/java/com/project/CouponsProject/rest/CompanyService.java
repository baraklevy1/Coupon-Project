package com.project.CouponsProject.rest;

import java.io.IOException;
import java.time.LocalDate;
import java.util.Collection;
import java.util.Collections;
import java.util.Date;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.ws.rs.Consumes;
import javax.ws.rs.core.Context;
import javax.ws.rs.core.MediaType;
import javax.ws.rs.core.Response;

import org.springframework.boot.json.JsonParseException;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestMethod;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.project.CouponsProject.entities.Income;
import com.project.CouponsProject.entities.IncomeType;
import com.project.CouponsProject.resources.ServerError;

import db.CompanyDao;
import ex.CouponAlreadyExistsException;
import ex.CouponNotExistsException;
import ex.InvalidLoginException;
import ex.NoSuchCompanyException;
import ex.SystemMalfunctionException;
import facade.CompanyFacade;
import facade.CouponSystem;
import facade.CustomerFacade;
import facade.LoginType;
import model.Company;
import model.Coupon;
import model.CouponCategory;

@RestController
@RequestMapping("company")
public class CompanyService {
	
	@Context
	private HttpServletRequest request;
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.GET, value = "/login", produces = MediaType.APPLICATION_JSON)
	private Response login(@RequestParam("name") String userName, @RequestParam("password") String password) {
			try {
				CompanyFacade facade = (CompanyFacade) CouponSystem.getInstance().login(userName, password,
						LoginType.COMPANY);
				return Response.ok("Login successfully!").build();
			} catch (InvalidLoginException e) {
				return Response.status(ServerError.INVALID_LOGIN).entity("Invalid Login Credentials!" + e.getMessage()).build();
			} catch (SystemMalfunctionException e) {
				return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unable to login!" + e.getMessage()).build();
			
			}		
	}
	
	private CompanyFacade getFacade(String userName, String password) {
		try {
			return (CompanyFacade) CouponSystem.getInstance().login(userName, password,
					LoginType.COMPANY);
		} catch (InvalidLoginException | SystemMalfunctionException e) {
			e.printStackTrace();
		}
		return null;
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.POST, value = "/createCoupon", consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public Response createCoupon(@RequestParam("name") String userName, @RequestParam("password") String password, @RequestBody Map<String, Object> CouponJson) {
		try {
			Coupon coupon = new Coupon();
			coupon.setTitle((String) CouponJson.get("title"));
			
			String startDate = (String) CouponJson.get("startDate");
			coupon.setStartDate(LocalDate.parse(startDate));

			String endDate = (String) CouponJson.get("endDate");
			coupon.setEndDate(LocalDate.parse(endDate));
			
			Number amount = (Number) CouponJson.get("amount");
			coupon.setAmount(amount.intValue());
			
			String category = (String) CouponJson.get("category");
			coupon.setCategory((CouponCategory.valueOf(category.toUpperCase())).ordinal());
			
			coupon.setMessage((String) CouponJson.get("message"));
			
			String price = String.valueOf((Number) CouponJson.get("price"));
			coupon.setPrice(Double.parseDouble(price));
			
			coupon.setImage((String) CouponJson.get("image"));
			
			System.out.println(coupon.toString());
			
			getFacade(userName, password).createCoupon(coupon);
			
			return Response.ok("Coupon was created successfully!").build();
		} catch (SystemMalfunctionException e) {
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unable to create coupon!" + e.getMessage()).build();
		} catch (CouponAlreadyExistsException e) {
			return Response.status(ServerError.COUPON_ALREADY_EXISTS).entity("Coupon with this name already exists!" + e.getMessage()).build();
		}
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.POST, value = "/removeCoupon")
	public Response removeCoupon(@RequestParam("name") String userName, @RequestParam("password") String password, @RequestParam("id") long couponId) {
		try {
			getFacade(userName, password).removeCoupon(couponId);
			return Response.ok("Coupon was removed successfully!").build();
		} catch (SystemMalfunctionException e) {
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unable to remove coupon!" + e.getMessage()).build();
		} catch (CouponNotExistsException e) {
			return Response.status(ServerError.NO_SUCH_COUPON).entity("Coupon not exists!" + e.getMessage()).build();
		}
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.POST, value = "/updateCoupon", consumes = MediaType.APPLICATION_JSON, produces = MediaType.APPLICATION_JSON)
	public Response updateCoupon(@RequestParam("name") String userName, @RequestParam("password") String password, @RequestBody Map<String, Object> CouponJson) {
		try {
			Coupon coupon = new Coupon();
			
			String id = String.valueOf((Number) CouponJson.get("id"));
			coupon.setId(Long.parseLong(id));
			
			coupon.setTitle((String) CouponJson.get("title"));
			
			String startDate = (String) CouponJson.get("startDate");
			coupon.setStartDate(LocalDate.parse(startDate));

			String endDate = (String) CouponJson.get("endDate");
			coupon.setEndDate(LocalDate.parse(endDate));
			
			Number amount = (Number) CouponJson.get("amount");
			coupon.setAmount(amount.intValue());
			
			System.out.println((int) CouponJson.get("category"));

			coupon.setCategory((int) CouponJson.get("category"));
			
			coupon.setMessage((String) CouponJson.get("message"));
			
			String price = String.valueOf((Number) CouponJson.get("price"));
			coupon.setPrice(Double.parseDouble(price));
			
			coupon.setImage((String) CouponJson.get("image"));
			
			getFacade(userName, password).updateCoupon(coupon);
			return Response.ok("Coupon was updated successfully!").build();
		} catch (SystemMalfunctionException e) {
			return Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unable to update coupon!" + e.getMessage()).build();
		} catch (CouponNotExistsException e) {
			return Response.status(ServerError.NO_SUCH_COUPON).entity("Coupon not exists!" + e.getMessage()).build();
		}
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.GET, value = "/getCoupon", produces = MediaType.APPLICATION_JSON)
	public Coupon getCoupon(@RequestParam("name") String userName, @RequestParam("password") String password, @RequestParam("id") long couponId) {
		try {
			return getFacade(userName, password).getCoupon(couponId);
		} catch (SystemMalfunctionException e) {
			Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unable to get coupon!" + e.getMessage()).build();
			return null;
		} catch (CouponNotExistsException e) {
			Response.status(ServerError.NO_SUCH_COUPON).entity("Coupon not exists!" + e.getMessage()).build();
			return null;
		}
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.GET, value = "/getAllCoupons", produces = MediaType.APPLICATION_JSON)
	public Collection<Coupon> getAllCoupons(@RequestParam("name") String userName, @RequestParam("password") String password) {
		try {
			return getFacade(userName, password).getAllCoupons();
		} catch (SystemMalfunctionException e) {
			Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unable to get all the coupons!" + e.getMessage()).build();
			return Collections.emptyList();
		}
	}
	
	@CrossOrigin(origins = "http://localhost:4200")
	@RequestMapping(method = RequestMethod.GET, value = "/getAllCouponsByType", produces = MediaType.APPLICATION_JSON)
	public Collection<Coupon> getAllCouponsByType(@RequestParam("name") String userName, @RequestParam("password") String password, @RequestParam("type") String type) {
		try {
			CouponCategory couponCategory = CouponCategory.valueOf(type.toUpperCase());
			return getFacade(userName, password).getCouponsByType(couponCategory);
		} catch (SystemMalfunctionException e) {
			Response.status(Response.Status.INTERNAL_SERVER_ERROR).entity("Unable to get all the coupons of type " + type.toString() + "!" + e.getMessage()).build();
			return Collections.emptyList();
		}
	}


}
