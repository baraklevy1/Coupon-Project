package com.project.CouponsProject.services;

import java.util.ArrayList;
import java.util.Collection;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.project.CouponsProject.entities.Income;
import com.project.CouponsProject.entities.IncomeType;
import com.project.CouponsProject.repositories.IncomeRepository;


@Service
public class IncomeServiceBean implements IncomeService {
	
	@Autowired
	IncomeRepository incomeRepository;
	
	public void storeIncome(Income income) {
		
		incomeRepository.save(income);
		
	}
	
	public Collection<Income> viewAllIncome() {
		
		return incomeRepository.findAll();
		
	}
	
	public Collection<Income> viewIncomeByCustomer(String userName) {
		
		Collection<Income> allIncomes = incomeRepository.findAll();
		
		Collection<Income> customerIncomes = new ArrayList<Income>(); 
		
		for (Income income : allIncomes) {
			if (income.getDescription().equals(IncomeType.CUSTOMER_PURCHASE) && income.getName().equals(userName)) {
				customerIncomes.add(income);
			}
		}
		
		return customerIncomes; 
		
	}
	
	public Collection<Income> viewIncomeByCompany(String userName) {
		
		Collection<Income> allIncomes = incomeRepository.findAll();
		
		Collection<Income> companyIncomes = new ArrayList<Income>(); 
		
		for (Income income : allIncomes) {
			if (income.getDescription().equals(IncomeType.COMPANY_CREATE_COUPON) && income.getName().equals(userName) || income.getDescription().equals(IncomeType.COMPANY_UPDATE_COUPON) && income.getName().equals(userName)) {
				companyIncomes.add(income);
			}
		}
		
		return companyIncomes; 
		
	}
	
	
}
